% Given parameters
fs = 100;  % Sampling frequency (Hz)

% Example signal (Replace with actual x[n])
x_n = [
    4; 1.8202; -1.3011; -0.8299; 1.6175; 1.7058; -0.1208; -0.1946; 1.3109; 0.8148; 
    -1.809; -2.5833; -0.2369; 1.5469; 0.1716; -2.0691; -2.2574; -1.1356; -0.7348; -0.821; 
    -0.309; 0.1429; -0.4964; -1.3815; -1.121; 0; 0.8718; 1.2568; 1.1933; 0.3364; 
    -0.691; -0.187; 1.8204; 2.7626; 1.3448; -0.167; 0.3062; 1.1858; 0.42; -0.4442; 
    0.809; 2.2411; 0.5673; -2.5941; -2.5904; 0.5302; 1.7776; -0.6165; -2.5427; -1.3199; 
    0; -1.3199; -2.5427; -0.6165; 1.7776; 0.5302; -2.5904; -2.5941; 0.5673; 2.2411; 
    0.809; -0.4442; 0.42; 1.1858; 0.3062; -0.167; 1.3448; 2.7626; 1.8204; -0.187; 
    -0.691; 0.3364; 1.1933; 1.2568; 0.8718; 0; -1.121; -1.3815; -0.4964; 0.1429; 
    -0.309; -0.821; -0.7348; -1.1356; -2.2574; -2.0691; 0.1716; 1.5469; -0.2369; -2.5833; 
    -1.809; 0.8148; 1.3109; -0.1946; -0.1208; 1.7058; 1.6175; -0.8299; -1.3011; 1.8202; 
    4; 1.8202; -1.3011; -0.8299; 1.6175; 1.7058; -0.1208; -0.1946; 1.3109; 0.8148; 
    -1.809; -2.5833; -0.2369; 1.5469; 0.1716; -2.0691
];

% Compute FFT
N = length(x_n); % Length of signal
X_f = fft(x_n);  % Compute FFT
frequencies = (-N/2:N/2-1) * (fs/N);  % Compute centered frequency bins
magnitudes = abs(fftshift(X_f));  % Remove /N normalization for better visibility

% Create a larger figure for better visualization
figure('Position', [100, 100, 1000, 600]); % Set figure size (width x height)

% Plot time-domain signal
subplot(2,1,1);
plot((0:N-1)/fs, x_n, 'k-', 'LineWidth', 1.5);
xlabel('Time (s)', 'FontSize', 14);
ylabel('Amplitude', 'FontSize', 14);
title('Time-Domain Signal', 'FontSize', 16);
grid on;
set(gca, 'FontSize', 12);

% Plot full frequency spectrum
subplot(2,1,2);
stem(frequencies, magnitudes, 'bo', 'MarkerSize', 5, 'LineWidth', 1.5); % Discrete markers
hold on;
xline(25, 'r--', 'Threshold (25 Hz)', 'LineWidth', 1.5, 'FontSize', 12, 'LabelVerticalAlignment', 'middle'); % Mark 25 Hz
xline(-25, 'r--', 'Threshold (-25 Hz)', 'LineWidth', 1.5, 'FontSize', 12, 'LabelVerticalAlignment', 'middle'); % Mark -25 Hz

xlabel('Frequency (Hz)', 'FontSize', 14);
ylabel('Magnitude', 'FontSize', 14);
title('Full Frequency Spectrum (Including Negative Frequencies)', 'FontSize', 16);
xlim([-fs/2 fs/2]); % Keep frequency range clear
ylim([0 max(magnitudes) * 1.2]); % Adjust y-axis
grid on;
hold off;
set(gca, 'FontSize', 12);

% Print frequency and corresponding magnitude
fprintf('Frequency (Hz) - Magnitude\n');
for i = 1:N
    fprintf('%6.2f Hz - %6.4f\n', frequencies(i), magnitudes(i));
end